package TP5_5;


/**
 * Write a description of class Lumi�re here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Lumi�re extends Object
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Lumi�re
     */
    public Lumi�re()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
